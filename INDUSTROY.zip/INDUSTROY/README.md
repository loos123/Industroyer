# Industrial Security Analysis Tool

A comprehensive analysis tool for industrial control system (ICS) security, designed to detect and analyze threats similar to the INDUSTROYER malware that targeted critical infrastructure.

## Features

- **Graphical User Interface**: Simple and intuitive GUI built with Tkinter
- **PCAP Analysis**: Automatic analysis of network captures focusing on industrial protocols
- **Detection Engine**: Flexible rule-based detection system for identifying threats
- **Logging System**: Comprehensive logging with multiple output formats
- **Custom Rule Management**: Ability to add, edit, and manage custom detection rules
- **Industrial Protocol Support**: Specialized analysis for IEC 60870-5-104, Modbus, DNP3, and S7COMM protocols

## Architecture

The tool is organized into several modules:

- `core/` - Main application and GUI framework
- `pcap_analysis/` - PCAP analysis and industrial protocol detection
- `detection/` - Detection engine and rule processing
- `logging/` - Comprehensive logging system
- `rules/` - Custom rule management interface

## Installation

1. Clone or download the repository
2. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

Run the application using:
```
python -m industroyer_analyzer
```

## Capabilities

- Analyze PCAP files for industrial protocol traffic
- Detect suspicious commands in ICS protocols
- Monitor live network traffic for anomalies
- Create and manage custom detection rules
- Generate detailed analysis reports
- Export logs and findings in multiple formats

## Supported Protocols

- IEC 60870-5-104 (IEC 104)
- Modbus TCP/RTU
- DNP3
- S7COMM/S7COMM Plus

## License

This project is created for educational and research purposes in the field of industrial cybersecurity.