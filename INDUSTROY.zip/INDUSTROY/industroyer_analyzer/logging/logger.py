"""
Logging System Module for Industrial Security Analysis Tool
Implements comprehensive logging with multiple output formats and filtering capabilities.
"""
import os
import json
import csv
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional
from enum import Enum
from dataclasses import dataclass, asdict
from pathlib import Path


class LogLevel(Enum):
    """Enumeration for log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


@dataclass
class LogEntry:
    """Represents a single log entry."""
    timestamp: datetime
    level: LogLevel
    module: str
    message: str
    details: Optional[Dict[str, Any]] = None
    thread_id: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert log entry to dictionary format."""
        result = {
            'timestamp': self.timestamp.isoformat(),
            'level': self.level.value,
            'module': self.module,
            'message': self.message,
            'thread_id': self.thread_id
        }
        if self.details:
            result['details'] = self.details
        return result


class IndustrialLogger:
    """
    Comprehensive logging system for the industrial security analysis tool.
    Supports multiple output formats and filtering capabilities.
    """
    
    def __init__(self, log_dir: str = "logs", max_log_size: int = 10 * 1024 * 1024):  # 10MB
        self.log_dir = Path(log_dir)
        self.max_log_size = max_log_size
        self.entries: List[LogEntry] = []
        self.min_level = LogLevel.INFO
        self.lock = threading.Lock()
        
        # Ensure log directory exists
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize log files
        self.current_log_file = self._get_log_filename()
        self._rotate_log_if_needed()
        
    def set_min_level(self, level: LogLevel):
        """
        Set minimum log level to store.
        
        Args:
            level: Minimum LogLevel to store
        """
        with self.lock:
            self.min_level = level
            
    def _get_log_filename(self) -> Path:
        """Generate a log filename with timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return self.log_dir / f"industrial_security_{timestamp}.log"
        
    def _should_log(self, level: LogLevel) -> bool:
        """Check if a log level should be recorded."""
        level_priority = {
            LogLevel.DEBUG: 0,
            LogLevel.INFO: 1,
            LogLevel.WARNING: 2,
            LogLevel.ERROR: 3,
            LogLevel.CRITICAL: 4
        }
        
        min_priority = level_priority[self.min_level]
        msg_priority = level_priority[level]
        
        return msg_priority >= min_priority
        
    def _rotate_log_if_needed(self):
        """Rotate log file if it exceeds maximum size."""
        if self.current_log_file.exists() and self.current_log_file.stat().st_size > self.max_log_size:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            rotated_name = self.log_dir / f"industrial_security_rotated_{timestamp}.log"
            self.current_log_file.rename(rotated_name)
            self.current_log_file = self._get_log_filename()
            
    def log(self, level: LogLevel, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """
        Add a log entry.
        
        Args:
            level: LogLevel of the entry
            module: Module name where log originated
            message: Log message
            details: Optional details dictionary
        """
        if not self._should_log(level):
            return
            
        entry = LogEntry(
            timestamp=datetime.now(),
            level=level,
            module=module,
            message=message,
            details=details,
            thread_id=threading.current_thread().ident
        )
        
        with self.lock:
            self.entries.append(entry)
            self._write_to_file(entry)
            
    def debug(self, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a debug message."""
        self.log(LogLevel.DEBUG, module, message, details)
        
    def info(self, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Log an info message."""
        self.log(LogLevel.INFO, module, message, details)
        
    def warning(self, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a warning message."""
        self.log(LogLevel.WARNING, module, message, details)
        
    def error(self, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Log an error message."""
        self.log(LogLevel.ERROR, module, message, details)
        
    def critical(self, module: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a critical message."""
        self.log(LogLevel.CRITICAL, module, message, details)
        
    def _write_to_file(self, entry: LogEntry):
        """Write log entry to the current log file."""
        try:
            self._rotate_log_if_needed()
            
            with open(self.current_log_file, 'a', encoding='utf-8') as f:
                log_line = f"[{entry.timestamp.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}] "
                log_line += f"[{entry.level.value}] "
                log_line += f"[{entry.module}] "
                log_line += f"{entry.message}"
                
                if entry.details:
                    log_line += f" | Details: {json.dumps(entry.details, default=str)}"
                    
                f.write(log_line + '\n')
        except Exception:
            # If file writing fails, we don't want to crash the application
            pass
            
    def get_entries(self, limit: int = 100, level_filter: Optional[LogLevel] = None) -> List[LogEntry]:
        """
        Get log entries with optional filtering.
        
        Args:
            limit: Maximum number of entries to return
            level_filter: Optional LogLevel to filter by
            
        Returns:
            List of LogEntry objects
        """
        with self.lock:
            filtered_entries = self.entries
            if level_filter:
                filtered_entries = [e for e in filtered_entries if e.level == level_filter]
                
            return filtered_entries[-limit:]
            
    def export_to_json(self, filepath: str, limit: int = 0) -> bool:
        """
        Export log entries to JSON file.
        
        Args:
            filepath: Path to output file
            limit: Number of entries to export (0 for all)
            
        Returns:
            True if export was successful, False otherwise
        """
        try:
            with self.lock:
                entries_to_export = self.entries
                if limit > 0:
                    entries_to_export = entries_to_export[-limit:]
                    
                data = [entry.to_dict() for entry in entries_to_export]
                
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
                
            return True
        except Exception:
            return False
            
    def export_to_csv(self, filepath: str, limit: int = 0) -> bool:
        """
        Export log entries to CSV file.
        
        Args:
            filepath: Path to output file
            limit: Number of entries to export (0 for all)
            
        Returns:
            True if export was successful, False otherwise
        """
        try:
            with self.lock:
                entries_to_export = self.entries
                if limit > 0:
                    entries_to_export = entries_to_export[-limit:]
                    
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['timestamp', 'level', 'module', 'message', 'details', 'thread_id']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for entry in entries_to_export:
                    row = {
                        'timestamp': entry.timestamp.isoformat(),
                        'level': entry.level.value,
                        'module': entry.module,
                        'message': entry.message,
                        'details': json.dumps(entry.details) if entry.details else '',
                        'thread_id': entry.thread_id
                    }
                    writer.writerow(row)
                    
            return True
        except Exception:
            return False
            
    def clear_logs(self):
        """Clear all log entries from memory."""
        with self.lock:
            self.entries.clear()
            
    def get_log_files(self) -> List[Path]:
        """Get list of all log files in the log directory."""
        try:
            return [f for f in self.log_dir.iterdir() if f.suffix == '.log']
        except Exception:
            return []
            
    def search_logs(self, search_term: str, level_filter: Optional[LogLevel] = None) -> List[LogEntry]:
        """
        Search log entries for a specific term.
        
        Args:
            search_term: Term to search for
            level_filter: Optional LogLevel to filter by
            
        Returns:
            List of matching LogEntry objects
        """
        with self.lock:
            results = []
            for entry in self.entries:
                if level_filter and entry.level != level_filter:
                    continue
                    
                # Search in message and details
                if (search_term.lower() in entry.message.lower() or
                    (entry.details and search_term.lower() in str(entry.details).lower())):
                    results.append(entry)
                    
            return results
            
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get logging system statistics.
        
        Returns:
            Dictionary with statistics
        """
        with self.lock:
            total_entries = len(self.entries)
            
            # Count by level
            level_counts = {}
            for entry in self.entries:
                level = entry.level.value
                level_counts[level] = level_counts.get(level, 0) + 1
                
            # Get log files
            log_files = self.get_log_files()
            total_file_size = sum(f.stat().st_size for f in log_files if f.exists())
            
            return {
                'total_entries': total_entries,
                'entries_by_level': level_counts,
                'log_directory': str(self.log_dir.absolute()),
                'log_files_count': len(log_files),
                'total_disk_usage': total_file_size,
                'current_file': str(self.current_log_file.name)
            }


class ModuleLogger:
    """
    Convenience wrapper for module-specific logging.
    """
    
    def __init__(self, logger: IndustrialLogger, module_name: str):
        self.logger = logger
        self.module_name = module_name
        
    def debug(self, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a debug message from this module."""
        self.logger.debug(self.module_name, message, details)
        
    def info(self, message: str, details: Optional[Dict[str, Any]] = None):
        """Log an info message from this module."""
        self.logger.info(self.module_name, message, details)
        
    def warning(self, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a warning message from this module."""
        self.logger.warning(self.module_name, message, details)
        
    def error(self, message: str, details: Optional[Dict[str, Any]] = None):
        """Log an error message from this module."""
        self.logger.error(self.module_name, message, details)
        
    def critical(self, message: str, details: Optional[Dict[str, Any]] = None):
        """Log a critical message from this module."""
        self.logger.critical(self.module_name, message, details)


# Global logger instance
_global_logger = None
_logger_lock = threading.Lock()


def get_logger(module_name: str) -> ModuleLogger:
    """
    Get a module-specific logger instance.
    
    Args:
        module_name: Name of the module requesting the logger
        
    Returns:
        ModuleLogger instance for the specified module
    """
    global _global_logger
    
    with _logger_lock:
        if _global_logger is None:
            _global_logger = IndustrialLogger()
            
    return ModuleLogger(_global_logger, module_name)


def set_global_logger(logger: IndustrialLogger):
    """
    Set the global logger instance.
    
    Args:
        logger: IndustrialLogger instance to use globally
    """
    global _global_logger
    
    with _logger_lock:
        _global_logger = logger