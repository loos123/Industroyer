"""
Main application class for the Industrial Security Analysis Tool.
This serves as the central hub connecting all components.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import json
from pathlib import Path


class IndustrialSecurityAnalyzer:
    """
    Main application class that orchestrates all components
    of the industrial security analysis tool.
    """
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Industrial Security Analyzer - INDUSTROYER Edition")
        self.root.geometry("1000x700")
        
        # Initialize components
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize the main user interface."""
        # Create main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="Industrial Security Analyzer", font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        # Create tabs
        self.create_analysis_tab()
        self.create_detection_tab()
        self.create_rules_tab()
        self.create_logs_tab()
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))
        
    def create_analysis_tab(self):
        """Create the PCAP analysis tab."""
        analysis_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(analysis_frame, text="PCAP Analysis")
        
        # File selection
        file_frame = ttk.LabelFrame(analysis_frame, text="PCAP File Selection", padding="10")
        file_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        file_frame.columnconfigure(1, weight=1)
        
        ttk.Label(file_frame, text="PCAP File:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.pcap_path = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.pcap_path, width=50).grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 5))
        ttk.Button(file_frame, text="Browse", command=self.browse_pcap).grid(row=0, column=2)
        ttk.Button(file_frame, text="Analyze", command=self.analyze_pcap).grid(row=0, column=3, padx=(5, 0))
        
        # Analysis results
        results_frame = ttk.LabelFrame(analysis_frame, text="Analysis Results", padding="10")
        results_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        # Text widget for results with scrollbar
        self.analysis_results = tk.Text(results_frame, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.analysis_results.yview)
        self.analysis_results.configure(yscrollcommand=scrollbar.set)
        
        self.analysis_results.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
    def create_detection_tab(self):
        """Create the detection engine tab."""
        detection_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(detection_frame, text="Detection Engine")
        
        # Detection status
        status_frame = ttk.LabelFrame(detection_frame, text="Detection Status", padding="10")
        status_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.detection_status = tk.StringVar(value="Inactive")
        self.detection_color = tk.StringVar(value="red")
        status_label = ttk.Label(status_frame, textvariable=self.detection_status, foreground=self.detection_color.get())
        status_label.grid(row=0, column=0, sticky=tk.W)
        
        # Control buttons
        control_frame = ttk.Frame(detection_frame)
        control_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.start_detection_btn = ttk.Button(control_frame, text="Start Detection", command=self.toggle_detection)
        self.start_detection_btn.grid(row=0, column=0, padx=(0, 10))
        
        # Live analysis results
        live_frame = ttk.LabelFrame(detection_frame, text="Live Analysis", padding="10")
        live_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        live_frame.columnconfigure(0, weight=1)
        live_frame.rowconfigure(0, weight=1)
        
        self.live_results = tk.Text(live_frame, wrap=tk.WORD)
        live_scrollbar = ttk.Scrollbar(live_frame, orient=tk.VERTICAL, command=self.live_results.yview)
        self.live_results.configure(yscrollcommand=live_scrollbar.set)
        
        self.live_results.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        live_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
    def create_rules_tab(self):
        """Create the custom rules management tab."""
        rules_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(rules_frame, text="Custom Rules")
        
        # Rule management
        rule_mgmt_frame = ttk.LabelFrame(rules_frame, text="Rule Management", padding="10")
        rule_mgmt_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        rule_mgmt_frame.columnconfigure(0, weight=1)
        
        # Buttons for rule management
        btn_frame = ttk.Frame(rule_mgmt_frame)
        btn_frame.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        ttk.Button(btn_frame, text="Add Rule", command=self.add_rule).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(btn_frame, text="Edit Rule", command=self.edit_rule).grid(row=0, column=1, padx=(0, 5))
        ttk.Button(btn_frame, text="Delete Rule", command=self.delete_rule).grid(row=0, column=2, padx=(0, 5))
        ttk.Button(btn_frame, text="Load Rules", command=self.load_rules).grid(row=0, column=3, padx=(0, 5))
        ttk.Button(btn_frame, text="Save Rules", command=self.save_rules).grid(row=0, column=4)
        
        # Rules list
        rules_list_frame = ttk.LabelFrame(rules_frame, text="Defined Rules", padding="10")
        rules_list_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        rules_list_frame.columnconfigure(0, weight=1)
        rules_list_frame.rowconfigure(0, weight=1)
        
        # Treeview for rules
        columns = ('Name', 'Type', 'Description')
        self.rules_tree = ttk.Treeview(rules_list_frame, columns=columns, show='headings', height=10)
        
        for col in columns:
            self.rules_tree.heading(col, text=col)
            self.rules_tree.column(col, width=150)
        
        rules_scrollbar = ttk.Scrollbar(rules_list_frame, orient=tk.VERTICAL, command=self.rules_tree.yview)
        self.rules_tree.configure(yscrollcommand=rules_scrollbar.set)
        
        self.rules_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        rules_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
    def create_logs_tab(self):
        """Create the logging tab."""
        logs_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(logs_frame, text="Logs")
        
        # Log controls
        log_controls = ttk.Frame(logs_frame)
        log_controls.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        ttk.Button(log_controls, text="Refresh Logs", command=self.refresh_logs).grid(row=0, column=0, padx=(0, 10))
        ttk.Button(log_controls, text="Clear Logs", command=self.clear_logs).grid(row=0, column=1, padx=(0, 10))
        ttk.Button(log_controls, text="Export Logs", command=self.export_logs).grid(row=0, column=2)
        
        # Log viewer
        log_viewer_frame = ttk.LabelFrame(logs_frame, text="Log Viewer", padding="10")
        log_viewer_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        log_viewer_frame.columnconfigure(0, weight=1)
        log_viewer_frame.rowconfigure(0, weight=1)
        
        self.log_viewer = tk.Text(log_viewer_frame, wrap=tk.WORD)
        log_viewer_scrollbar = ttk.Scrollbar(log_viewer_frame, orient=tk.VERTICAL, command=self.log_viewer.yview)
        self.log_viewer.configure(yscrollcommand=log_viewer_scrollbar.set)
        
        self.log_viewer.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        log_viewer_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
    def browse_pcap(self):
        """Open file dialog to select a PCAP file."""
        file_path = filedialog.askopenfilename(
            title="Select PCAP File",
            filetypes=[("PCAP Files", "*.pcap *.pcapng"), ("All Files", "*.*")]
        )
        if file_path:
            self.pcap_path.set(file_path)
            
    def analyze_pcap(self):
        """Start PCAP analysis in a separate thread."""
        pcap_file = self.pcap_path.get()
        if not pcap_file:
            messagebox.showwarning("Warning", "Please select a PCAP file first.")
            return
            
        # Show loading status
        self.status_var.set("Analyzing PCAP file...")
        self.analysis_results.delete(1.0, tk.END)
        self.analysis_results.insert(tk.END, "Starting analysis...\n")
        
        # Run analysis in a separate thread to keep UI responsive
        thread = threading.Thread(target=self._perform_pcap_analysis, args=(pcap_file,))
        thread.daemon = True
        thread.start()
        
    def _perform_pcap_analysis(self, pcap_file):
        """Perform the actual PCAP analysis (to be implemented in pcap_analysis module)."""
        # This will be connected to the actual PCAP analysis module
        result = f"PCAP Analysis Results for: {pcap_file}\n\n"
        result += "This is a placeholder for the actual PCAP analysis.\n"
        result += "The analysis would include:\n"
        result += "- Protocol identification (IEC 104, Modbus, DNP3, S7Comm)\n"
        result += "- Traffic pattern analysis\n"
        result += "- Anomaly detection\n"
        result += "- Industrial protocol command extraction\n"
        
        # Update UI in the main thread
        self.root.after(0, self._update_analysis_results, result)
        
    def _update_analysis_results(self, result):
        """Update the analysis results text widget."""
        self.analysis_results.delete(1.0, tk.END)
        self.analysis_results.insert(tk.END, result)
        self.status_var.set("PCAP analysis completed")
        
    def toggle_detection(self):
        """Toggle the detection engine."""
        # This will be connected to the actual detection engine
        if self.detection_status.get() == "Active":
            self.detection_status.set("Inactive")
            self.detection_color.set("red")
            self.start_detection_btn.config(text="Start Detection")
            self.live_results.insert(tk.END, "[INFO] Detection stopped\n")
        else:
            self.detection_status.set("Active")
            self.detection_color.set("green")
            self.start_detection_btn.config(text="Stop Detection")
            self.live_results.insert(tk.END, "[INFO] Detection started\n")
            
    def add_rule(self):
        """Open dialog to add a new rule."""
        # Placeholder for rule addition
        messagebox.showinfo("Info", "Rule addition functionality will be implemented in the rules module.")
        
    def edit_rule(self):
        """Edit selected rule."""
        # Placeholder for rule editing
        messagebox.showinfo("Info", "Rule editing functionality will be implemented in the rules module.")
        
    def delete_rule(self):
        """Delete selected rule."""
        # Placeholder for rule deletion
        messagebox.showinfo("Info", "Rule deletion functionality will be implemented in the rules module.")
        
    def load_rules(self):
        """Load rules from file."""
        # Placeholder for rule loading
        messagebox.showinfo("Info", "Rule loading functionality will be implemented in the rules module.")
        
    def save_rules(self):
        """Save rules to file."""
        # Placeholder for rule saving
        messagebox.showinfo("Info", "Rule saving functionality will be implemented in the rules module.")
        
    def refresh_logs(self):
        """Refresh the log display."""
        # Placeholder for log refreshing
        self.log_viewer.delete(1.0, tk.END)
        self.log_viewer.insert(tk.END, "Log refresh functionality will be implemented in the logging module.\n")
        
    def clear_logs(self):
        """Clear the log display."""
        self.log_viewer.delete(1.0, tk.END)
        
    def export_logs(self):
        """Export logs to file."""
        # Placeholder for log export
        messagebox.showinfo("Info", "Log export functionality will be implemented in the logging module.")
        
    def run(self):
        """Start the application."""
        self.root.mainloop()