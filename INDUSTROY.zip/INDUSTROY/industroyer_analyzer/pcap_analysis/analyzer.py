"""
PCAP Analysis Module for Industrial Security Analysis Tool
Handles the automatic analysis of PCAP files focusing on industrial protocols.
"""
import os
import sys
from typing import Dict, List, Tuple, Optional
import struct
from datetime import datetime
import socket

try:
    import dpkt
except ImportError:
    print("dpkt library not found. Install it with: pip install dpkt")
    sys.exit(1)


class IndustrialProtocolDetector:
    """
    Detects and analyzes industrial protocols in network traffic.
    Supports IEC 60870-5-104, Modbus, DNP3, and S7COMM protocols.
    """
    
    def __init__(self):
        self.protocol_stats = {
            'iec_104': {'count': 0, 'sessions': []},
            'modbus': {'count': 0, 'sessions': []},
            'dnp3': {'count': 0, 'sessions': []},
            's7comm': {'count': 0, 'sessions': []},
            'total_packets': 0
        }
        self.sessions = []
        
    def analyze_pcap(self, pcap_file_path: str) -> Dict:
        """
        Analyze a PCAP file and return statistics about industrial protocols.
        
        Args:
            pcap_file_path: Path to the PCAP file to analyze
            
        Returns:
            Dictionary containing analysis results
        """
        if not os.path.exists(pcap_file_path):
            raise FileNotFoundError(f"PCAP file not found: {pcap_file_path}")
            
        with open(pcap_file_path, 'rb') as f:
            try:
                pcap = dpkt.pcap.Reader(f)
            except Exception as e:
                raise ValueError(f"Could not read PCAP file: {str(e)}")
                
            for timestamp, buf in pcap:
                self.protocol_stats['total_packets'] += 1
                try:
                    eth = dpkt.ethernet.Ethernet(buf)
                    if isinstance(eth.data, dpkt.ip.IP):
                        ip = eth.data
                        if isinstance(ip.data, dpkt.tcp.TCP):
                            tcp = ip.data
                            src_ip = socket.inet_ntoa(ip.src)
                            dst_ip = socket.inet_ntoa(ip.dst)
                            
                            # Check for industrial protocols by port or payload
                            session_info = {
                                'timestamp': timestamp,
                                'src_ip': src_ip,
                                'dst_ip': dst_ip,
                                'src_port': tcp.sport,
                                'dst_port': tcp.dport,
                                'payload': tcp.data,
                                'protocol': None,
                                'details': {}
                            }
                            
                            detected_protocol = self.detect_protocol(tcp, session_info)
                            if detected_protocol:
                                session_info['protocol'] = detected_protocol
                                self.protocol_stats[detected_protocol]['count'] += 1
                                self.protocol_stats[detected_protocol]['sessions'].append(session_info)
                                self.sessions.append(session_info)
                                
                        elif isinstance(ip.data, dpkt.udp.UDP):
                            udp = ip.data
                            src_ip = socket.inet_ntoa(ip.src)
                            dst_ip = socket.inet_ntoa(ip.dst)
                            
                            session_info = {
                                'timestamp': timestamp,
                                'src_ip': src_ip,
                                'dst_ip': dst_ip,
                                'src_port': udp.sport,
                                'dst_port': udp.dport,
                                'payload': udp.data,
                                'protocol': None,
                                'details': {}
                            }
                            
                            # Some industrial protocols use UDP too
                            detected_protocol = self.detect_udp_protocol(udp, session_info)
                            if detected_protocol:
                                session_info['protocol'] = detected_protocol
                                self.protocol_stats[detected_protocol]['count'] += 1
                                self.protocol_stats[detected_protocol]['sessions'].append(session_info)
                                self.sessions.append(session_info)
                except Exception:
                    # Skip malformed packets
                    continue
                                
            return self.generate_report()
            
    def detect_protocol(self, tcp_pkt, session_info: Dict) -> Optional[str]:
        """
        Detect industrial protocols in TCP packets.
        
        Args:
            tcp_pkt: TCP packet object from dpkt
            session_info: Session information dictionary
            
        Returns:
            Detected protocol name or None
        """
        payload = tcp_pkt.data
        
        if len(payload) < 2:
            return None
            
        # IEC 60870-5-104 detection
        # IEC 104 uses APDU format: Starts with 0x68 (APCI start) followed by length
        if (len(payload) >= 4 and 
            payload[0] == 0x68 and 
            payload[1] <= 253 and  # Length field
            tcp_pkt.dport == 2404):  # Standard IEC 104 port
            return 'iec_104'
            
        # Modbus detection
        # Modbus TCP: MBAP header (7 bytes) + PDU
        if (len(payload) >= 7 and
            tcp_pkt.dport in [502, 1502] and  # Standard Modbus ports
            payload[2] == 0 and payload[3] == 0):  # Length field check
            return 'modbus'
            
        # DNP3 detection
        # DNP3 starts with 0x05 0x64 (DNP3 Link Header)
        if (len(payload) >= 10 and
            payload[0] == 0x05 and payload[1] == 0x64):
            return 'dnp3'
            
        # S7COMM detection (basic)
        # S7COMM packet starts with specific magic bytes
        if (len(payload) >= 4 and
            tcp_pkt.dport == 102 and  # ISO on TCP/RFC 1006
            payload[0] == 0x03):  # Likely S7COMM Plus
            return 's7comm'
            
        return None
        
    def detect_udp_protocol(self, udp_pkt, session_info: Dict) -> Optional[str]:
        """
        Detect industrial protocols in UDP packets.
        
        Args:
            udp_pkt: UDP packet object from dpkt
            session_info: Session information dictionary
            
        Returns:
            Detected protocol name or None
        """
        # For now, focus on TCP-based industrial protocols
        # Some industrial protocols do use UDP but are less common
        return None
        
    def generate_report(self) -> Dict:
        """
        Generate a comprehensive report of the analysis.
        
        Returns:
            Dictionary containing the analysis report
        """
        report = {
            'summary': {
                'total_packets': self.protocol_stats['total_packets'],
                'iec_104_count': self.protocol_stats['iec_104']['count'],
                'modbus_count': self.protocol_stats['modbus']['count'],
                'dnp3_count': self.protocol_stats['dnp3']['count'],
                's7comm_count': self.protocol_stats['s7comm']['count'],
                'detection_timestamp': datetime.now().isoformat()
            },
            'protocols': {
                'iec_104': {
                    'count': self.protocol_stats['iec_104']['count'],
                    'sessions': self.format_sessions(self.protocol_stats['iec_104']['sessions'])
                },
                'modbus': {
                    'count': self.protocol_stats['modbus']['count'],
                    'sessions': self.format_sessions(self.protocol_stats['modbus']['sessions'])
                },
                'dnp3': {
                    'count': self.protocol_stats['dnp3']['count'],
                    'sessions': self.format_sessions(self.protocol_stats['dnp3']['sessions'])
                },
                's7comm': {
                    'count': self.protocol_stats['s7comm']['count'],
                    'sessions': self.format_sessions(self.protocol_stats['s7comm']['sessions'])
                }
            },
            'network_map': self.build_network_map(),
            'anomalies': self.detect_anomalies()
        }
        
        return report
    
    def format_sessions(self, sessions: List[Dict]) -> List[Dict]:
        """
        Format session data for reporting.
        
        Args:
            sessions: List of session dictionaries
            
        Returns:
            Formatted session data
        """
        formatted = []
        for session in sessions[:10]:  # Limit to first 10 for brevity
            formatted.append({
                'timestamp': datetime.fromtimestamp(session['timestamp']).strftime('%Y-%m-%d %H:%M:%S'),
                'source': f"{session['src_ip']}:{session['src_port']}",
                'destination': f"{session['dst_ip']}:{session['dst_port']}",
                'payload_size': len(session['payload']),
                'raw_hex': session['payload'][:50].hex() if len(session['payload']) > 0 else ''
            })
        return formatted
    
    def build_network_map(self) -> Dict:
        """
        Build a network map showing communication patterns.
        
        Returns:
            Dictionary representing network communication
        """
        hosts = set()
        connections = []
        
        for session in self.sessions:
            src_host = session['src_ip']
            dst_host = session['dst_ip']
            protocol = session['protocol']
            
            hosts.add(src_host)
            hosts.add(dst_host)
            connections.append({
                'source': src_host,
                'destination': dst_host,
                'protocol': protocol,
                'port': session['dst_port']
            })
        
        return {
            'hosts': list(hosts),
            'connections': connections,
            'total_hosts': len(hosts)
        }
    
    def detect_anomalies(self) -> List[Dict]:
        """
        Detect anomalies in the network traffic.
        
        Returns:
            List of detected anomalies
        """
        anomalies = []
        
        # Check for unusual protocol usage
        if self.protocol_stats['iec_104']['count'] > 0:
            # Look for IEC 104 commands that shouldn't occur frequently
            iec104_sessions = self.protocol_stats['iec_104']['sessions']
            for session in iec104_sessions:
                # Look for potential command injections
                payload = session['payload']
                if len(payload) >= 6:
                    # Check for Type IDs that indicate control commands
                    type_id = payload[4] if len(payload) > 4 else 0
                    if type_id in [0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37]:  # Control commands
                        anomalies.append({
                            'type': 'Industrial Control Command',
                            'severity': 'HIGH',
                            'description': f'Suspicious IEC 104 control command detected: Type ID {type_id}',
                            'timestamp': datetime.fromtimestamp(session['timestamp']).strftime('%Y-%m-%d %H:%M:%S'),
                            'source': f"{session['src_ip']}:{session['src_port']}",
                            'destination': f"{session['dst_ip']}:{session['dst_port']}"
                        })
        
        # Check for Modbus function codes that indicate writes
        if self.protocol_stats['modbus']['count'] > 0:
            modbus_sessions = self.protocol_stats['modbus']['sessions']
            for session in modbus_sessions:
                payload = session['payload']
                if len(payload) >= 7:
                    # Extract function code (byte 7 in Modbus TCP)
                    func_code = payload[7] if len(payload) > 7 else 0
                    if func_code in [5, 6, 15, 16]:  # Write functions
                        anomalies.append({
                            'type': 'Modbus Write Command',
                            'severity': 'MEDIUM',
                            'description': f'Modbus write command detected: Function {func_code}',
                            'timestamp': datetime.fromtimestamp(session['timestamp']).strftime('%Y-%m-%d %H:%M:%S'),
                            'source': f"{session['src_ip']}:{session['src_port']}",
                            'destination': f"{session['dst_ip']}:{session['dst_port']}"
                        })
        
        return anomalies


class PCAPAnalyzer:
    """
    Main PCAP analyzer class that integrates with the application.
    """
    
    def __init__(self):
        self.detector = IndustrialProtocolDetector()
        
    def analyze_file(self, file_path: str) -> str:
        """
        Analyze a PCAP file and return formatted results.
        
        Args:
            file_path: Path to the PCAP file to analyze
            
        Returns:
            Formatted analysis results as a string
        """
        try:
            results = self.detector.analyze_pcap(file_path)
            return self.format_results(results)
        except Exception as e:
            return f"Error analyzing PCAP file: {str(e)}"
    
    def format_results(self, results: Dict) -> str:
        """
        Format analysis results for display.
        
        Args:
            results: Analysis results dictionary
            
        Returns:
            Formatted results as a string
        """
        output = []
        output.append("=" * 60)
        output.append("INDUSTRIAL PROTOCOL ANALYSIS REPORT")
        output.append("=" * 60)
        output.append("")
        
        # Summary
        summary = results['summary']
        output.append("SUMMARY:")
        output.append(f"  Total Packets Analyzed: {summary['total_packets']}")
        output.append(f"  IEC 60870-5-104 Packets: {summary['iec_104_count']}")
        output.append(f"  Modbus Packets: {summary['modbus_count']}")
        output.append(f"  DNP3 Packets: {summary['dnp3_count']}")
        output.append(f"  S7COMM Packets: {summary['s7comm_count']}")
        output.append(f"  Analysis Time: {summary['detection_timestamp']}")
        output.append("")
        
        # Protocol details
        output.append("PROTOCOL DETAILS:")
        for proto, data in results['protocols'].items():
            if data['count'] > 0:
                output.append(f"  {proto.upper()} ({data['count']} packets):")
                for session in data['sessions']:
                    output.append(f"    - {session['timestamp']} | {session['source']} -> {session['destination']} | Size: {session['payload_size']}")
                    if session['raw_hex']:
                        output.append(f"      Payload (hex): {session['raw_hex']}")
                output.append("")
        
        # Network map
        net_map = results['network_map']
        output.append("NETWORK MAP:")
        output.append(f"  Total Hosts: {net_map['total_hosts']}")
        output.append(f"  Connections: {len(net_map['connections'])}")
        for conn in net_map['connections'][:10]:  # Show first 10 connections
            output.append(f"    {conn['source']} -> {conn['destination']} ({conn['protocol']}:{conn['port']})")
        output.append("")
        
        # Anomalies
        anomalies = results['anomalies']
        if anomalies:
            output.append("DETECTED ANOMALIES:")
            for anomaly in anomalies:
                output.append(f"  [{anomaly['severity']}] {anomaly['type']}")
                output.append(f"    Description: {anomaly['description']}")
                output.append(f"    Time: {anomaly['timestamp']}")
                output.append(f"    Source: {anomaly['source']} -> Destination: {anomaly['destination']}")
                output.append("")
        else:
            output.append("NO ANOMALIES DETECTED")
            output.append("")
        
        output.append("=" * 60)
        
        return "\n".join(output)