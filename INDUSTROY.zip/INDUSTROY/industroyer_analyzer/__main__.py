"""
Main Entry Point for Industrial Security Analysis Tool
Integrates all modules: GUI, PCAP analysis, detection engine, logging, and rule management.
"""
import sys
import os
from pathlib import Path

# Add the project root to the path so imports work correctly
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from industroyer_analyzer.core.application import IndustrialSecurityAnalyzer
from industroyer_analyzer.pcap_analysis.analyzer import PCAPAnalyzer
from industroyer_analyzer.detection.engine import DetectionEngine, LiveDetectionManager
from industroyer_analyzer.logging.logger import get_logger, set_global_logger, IndustrialLogger
from industroyer_analyzer.rules.manager import RuleManager


def main():
    """
    Main function to initialize and run the Industrial Security Analysis Tool.
    """
    print("Initializing Industrial Security Analysis Tool...")
    print("Loading components...")
    
    # Initialize the global logger first
    logger = IndustrialLogger()
    set_global_logger(logger)
    app_logger = get_logger("Application")
    
    # Initialize all components
    try:
        # Initialize the main application
        app = IndustrialSecurityAnalyzer()
        
        # Initialize PCAP analyzer
        pcap_analyzer = PCAPAnalyzer()
        
        # Initialize detection engine
        detection_engine = DetectionEngine()
        
        # Initialize rule manager
        rule_manager = RuleManager()
        
        # Initialize live detection manager
        live_detection = LiveDetectionManager(detection_engine)
        
        # Connect components to the main application
        # We'll monkey-patch these onto the app instance for now
        app.pcap_analyzer = pcap_analyzer
        app.detection_engine = detection_engine
        app.rule_manager = rule_manager
        app.live_detection = live_detection
        
        # Update the application's internal methods to use the actual components
        def patched_perform_pcap_analysis(self, pcap_file):
            """Patched method to use actual PCAP analyzer."""
            result = self.pcap_analyzer.analyze_file(pcap_file)
            
            # Update UI in the main thread
            self.root.after(0, self._update_analysis_results, result)
            
        def patched_toggle_detection(self):
            """Patched method to use actual detection engine."""
            if self.detection_status.get() == "Active":
                self.live_detection.stop_monitoring()
                self.detection_status.set("Inactive")
                self.detection_color.set("red")
                self.start_detection_btn.config(text="Start Detection")
                self.live_results.insert(tk.END, "[INFO] Detection stopped\n")
            else:
                self.live_detection.start_monitoring()
                self.detection_status.set("Active")
                self.detection_color.set("green")
                self.start_detection_btn.config(text="Stop Detection")
                self.live_results.insert(tk.END, "[INFO] Detection started\n")
                
        def patched_add_rule(self):
            """Patched method to use actual rule manager."""
            # Import tkinter here to avoid circular import issues
            import tkinter.simpledialog as simpledialog
            import tkinter.messagebox as messagebox
            
            rule_id = simpledialog.askstring("Add Rule", "Enter Rule ID:")
            if not rule_id:
                return
                
            name = simpledialog.askstring("Add Rule", "Enter Rule Name:")
            if not name:
                return
                
            # Simple rule type selection
            import tkinter as tk
            from detection.engine import RuleType, Severity
            
            rule_type_str = simpledialog.askstring("Add Rule", "Enter Rule Type (regex, protocol, network, custom):")
            if not rule_type_str:
                return
                
            try:
                rule_type = RuleType(rule_type_str.lower())
            except ValueError:
                messagebox.showerror("Error", f"Invalid rule type: {rule_type_str}")
                return
                
            pattern = simpledialog.askstring("Add Rule", "Enter Pattern:")
            if not pattern:
                return
                
            severity_str = simpledialog.askstring("Add Rule", "Enter Severity (LOW, MEDIUM, HIGH, CRITICAL):")
            if not severity_str:
                return
                
            try:
                severity = Severity(severity_str.upper())
            except ValueError:
                messagebox.showerror("Error", f"Invalid severity: {severity_str}")
                return
                
            description = simpledialog.askstring("Add Rule", "Enter Description (optional):") or ""
            
            # Create the rule
            success = self.rule_manager.create_rule(rule_id, name, rule_type, pattern, severity, description)
            if success:
                # Refresh the rules treeview
                self._refresh_rules_display()
                messagebox.showinfo("Success", f"Rule '{rule_id}' added successfully!")
            else:
                messagebox.showerror("Error", f"Failed to add rule '{rule_id}'. ID may already exist.")
                
        def patched_edit_rule(self):
            """Patched method to edit selected rule."""
            import tkinter.simpledialog as simpledialog
            import tkinter.messagebox as messagebox
            
            # Get selected item
            selected_item = self.rules_tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a rule to edit.")
                return
                
            # Get rule ID from the selected item
            rule_id = self.rules_tree.item(selected_item[0], 'values')[0]  # Assuming first column is ID
            
            # Get the rule from rule manager
            rule = self.rule_manager.get_rule(rule_id)
            if not rule:
                messagebox.showerror("Error", f"Rule '{rule_id}' not found.")
                return
                
            # Create edit dialog (simplified)
            name = simpledialog.askstring("Edit Rule", "Enter Rule Name:", initialvalue=rule.name)
            if name is None:
                return  # User cancelled
                
            pattern = simpledialog.askstring("Edit Rule", "Enter Pattern:", initialvalue=rule.pattern)
            if pattern is None:
                return  # User cancelled
                
            description = simpledialog.askstring("Edit Rule", "Enter Description:", initialvalue=rule.description)
            if description is None:
                return  # User cancelled
                
            # Update the rule
            success = self.rule_manager.update_rule(
                rule_id=rule_id,
                name=name,
                pattern=pattern,
                description=description
            )
            
            if success:
                # Refresh the rules treeview
                self._refresh_rules_display()
                messagebox.showinfo("Success", f"Rule '{rule_id}' updated successfully!")
            else:
                messagebox.showerror("Error", f"Failed to update rule '{rule_id}'.")
                
        def patched_delete_rule(self):
            """Patched method to delete selected rule."""
            import tkinter.messagebox as messagebox
            
            # Get selected item
            selected_item = self.rules_tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a rule to delete.")
                return
                
            # Get rule ID from the selected item
            rule_id = self.rules_tree.item(selected_item[0], 'values')[0]
            
            # Confirm deletion
            if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete rule '{rule_id}'?"):
                success = self.rule_manager.delete_rule(rule_id)
                if success:
                    # Refresh the rules treeview
                    self._refresh_rules_display()
                    messagebox.showinfo("Success", f"Rule '{rule_id}' deleted successfully!")
                else:
                    messagebox.showerror("Error", f"Failed to delete rule '{rule_id}'.")
                    
        def patched_load_rules(self):
            """Patched method to load rules from file."""
            import tkinter.messagebox as messagebox
            
            success = self.rule_manager.load_rules()
            if success:
                self._refresh_rules_display()
                messagebox.showinfo("Success", "Rules loaded successfully!")
            else:
                messagebox.showerror("Error", "Failed to load rules.")
                
        def patched_save_rules(self):
            """Patched method to save rules to file."""
            import tkinter.messagebox as messagebox
            
            success = self.rule_manager.save_rules()
            if success:
                messagebox.showinfo("Success", "Rules saved successfully!")
            else:
                messagebox.showerror("Error", "Failed to save rules.")
                
        def patched_refresh_logs(self):
            """Patched method to refresh log display."""
            # Clear the log viewer
            self.log_viewer.delete(1.0, tk.END)
            
            # Get recent log entries
            from industroyer_analyzer.logging.logger import _global_logger  # Import here to avoid circular import
            if _global_logger:
                recent_logs = _global_logger.get_entries(limit=100)
                for log_entry in recent_logs:
                    self.log_viewer.insert(tk.END, f"[{log_entry.timestamp.strftime('%Y-%m-%d %H:%M:%S')}] ")
                    self.log_viewer.insert(tk.END, f"[{log_entry.level.value}] ")
                    self.log_viewer.insert(tk.END, f"[{log_entry.module}] ")
                    self.log_viewer.insert(tk.END, f"{log_entry.message}\n")
            else:
                self.log_viewer.insert(tk.END, "Logger not initialized.\n")
                
        def patched_export_logs(self):
            """Patched method to export logs."""
            import tkinter.filedialog as filedialog
            import tkinter.messagebox as messagebox
            
            filepath = filedialog.asksaveasfilename(
                title="Export Logs",
                defaultextension=".json",
                filetypes=[("JSON files", "*.json"), ("CSV files", "*.csv"), ("Text files", "*.txt")]
            )
            
            if filepath:
                from industroyer_analyzer.logging.logger import _global_logger  # Import here to avoid circular import
                if _global_logger:
                    # Determine format from extension
                    if filepath.endswith('.json'):
                        success = _global_logger.export_to_json(filepath, limit=500)
                    elif filepath.endswith('.csv'):
                        success = _global_logger.export_to_csv(filepath, limit=500)
                    else:
                        # For text files, just save recent logs
                        try:
                            recent_logs = _global_logger.get_entries(limit=500)
                            with open(filepath, 'w', encoding='utf-8') as f:
                                for log_entry in recent_logs:
                                    f.write(f"[{log_entry.timestamp.strftime('%Y-%m-%d %H:%M:%S')}] ")
                                    f.write(f"[{log_entry.level.value}] ")
                                    f.write(f"[{log_entry.module}] ")
                                    f.write(f"{log_entry.message}")
                                    if log_entry.details:
                                        f.write(f" | Details: {log_entry.details}")
                                    f.write("\n")
                            success = True
                        except Exception:
                            success = False
                            
                    if success:
                        messagebox.showinfo("Success", f"Logs exported to {filepath}")
                    else:
                        messagebox.showerror("Error", "Failed to export logs.")
                else:
                    messagebox.showerror("Error", "Logger not initialized.")
                    
        def patched_clear_logs(self):
            """Patched method to clear logs."""
            import tkinter.messagebox as messagebox
            
            if messagebox.askyesno("Confirm Clear", "Are you sure you want to clear all logs?"):
                from industroyer_analyzer.logging.logger import _global_logger  # Import here to avoid circular import
                if _global_logger:
                    _global_logger.clear_logs()
                    self.log_viewer.delete(1.0, tk.END)
                    messagebox.showinfo("Success", "Logs cleared successfully!")
                    
        def _refresh_rules_display(self):
            """Helper method to refresh the rules treeview."""
            # Clear existing items
            for item in self.rules_tree.get_children():
                self.rules_tree.delete(item)
                
            # Add current rules
            rules = self.rule_manager.get_all_rules()
            for rule in rules:
                self.rules_tree.insert('', 'end', values=(
                    rule.id,
                    rule.rule_type.value,
                    rule.description
                ))
        
        # Apply patches to the app instance
        import tkinter as tk
        app._perform_pcap_analysis = lambda pcap_file: patched_perform_pcap_analysis(app, pcap_file)
        app.toggle_detection = lambda: patched_toggle_detection(app)
        app.add_rule = lambda: patched_add_rule(app)
        app.edit_rule = lambda: patched_edit_rule(app)
        app.delete_rule = lambda: patched_delete_rule(app)
        app.load_rules = lambda: patched_load_rules(app)
        app.save_rules = lambda: patched_save_rules(app)
        app.refresh_logs = lambda: patched_refresh_logs(app)
        app.export_logs = lambda: patched_export_logs(app)
        app.clear_logs = lambda: patched_clear_logs(app)
        app._refresh_rules_display = lambda: _refresh_rules_display(app)
        
        # Initialize the rules display
        app._refresh_rules_display()
        
        # Log initialization
        app_logger.info("Industrial Security Analysis Tool initialized successfully")
        print("Initialization complete. Starting application...")
        
        # Run the application
        app.run()
        
    except Exception as e:
        app_logger.critical("Failed to initialize application", {"error": str(e)})
        print(f"Error initializing application: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()