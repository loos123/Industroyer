"""
Industrial Security Analysis Tool - Package Initialization

This package provides comprehensive analysis capabilities for industrial control system security,
with a focus on detecting and analyzing threats similar to the INDUSTROYER malware.
"""

__version__ = "1.0.0"
__author__ = "Industrial Security Research Team"
__description__ = "Comprehensive Industrial Security Analysis Tool for ICS/SCADA Environments"