"""
Detection Engine Module for Industrial Security Analysis Tool
Implements a flexible detection system with custom rule processing capabilities.
"""
import re
import json
import threading
import time
from typing import Dict, List, Any, Callable, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class Severity(Enum):
    """Enumeration for alert severity levels."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RuleType(Enum):
    """Enumeration for rule types."""
    REGEX = "regex"
    PROTOCOL = "protocol"
    NETWORK = "network"
    CUSTOM = "custom"


@dataclass
class DetectionRule:
    """Represents a single detection rule."""
    id: str
    name: str
    rule_type: RuleType
    pattern: str
    severity: Severity
    enabled: bool
    description: str = ""
    callback: Optional[Callable] = None


@dataclass
class DetectionAlert:
    """Represents a detection alert."""
    rule_id: str
    rule_name: str
    severity: Severity
    timestamp: datetime
    source: str
    destination: str
    details: Dict[str, Any]
    matched_data: str = ""


class DetectionEngine:
    """
    Core detection engine that processes network traffic and applies detection rules.
    """
    
    def __init__(self):
        self.rules: List[DetectionRule] = []
        self.alerts: List[DetectionAlert] = []
        self.is_running = False
        self.callbacks = {}
        self.lock = threading.Lock()
        
        # Register built-in callbacks
        self._register_built_in_callbacks()
        
    def _register_built_in_callbacks(self):
        """Register built-in detection callbacks."""
        self.callbacks['iec104_suspicious_command'] = self._check_iec104_suspicious_command
        self.callbacks['modbus_write_command'] = self._check_modbus_write_command
        self.callbacks['dnp3_unauthorized_control'] = self._check_dnp3_unauthorized_control
        self.callbacks['s7comm_session_init'] = self._check_s7comm_session_init
        self.callbacks['unusual_port_access'] = self._check_unusual_port_access
        
    def add_rule(self, rule: DetectionRule) -> bool:
        """
        Add a new detection rule to the engine.
        
        Args:
            rule: DetectionRule object to add
            
        Returns:
            True if rule was added successfully, False otherwise
        """
        with self.lock:
            # Check if rule ID already exists
            for existing_rule in self.rules:
                if existing_rule.id == rule.id:
                    return False
                    
            self.rules.append(rule)
            return True
            
    def remove_rule(self, rule_id: str) -> bool:
        """
        Remove a detection rule by ID.
        
        Args:
            rule_id: ID of the rule to remove
            
        Returns:
            True if rule was removed, False if not found
        """
        with self.lock:
            for i, rule in enumerate(self.rules):
                if rule.id == rule_id:
                    del self.rules[i]
                    return True
            return False
            
    def enable_rule(self, rule_id: str, enabled: bool = True) -> bool:
        """
        Enable or disable a rule.
        
        Args:
            rule_id: ID of the rule to modify
            enabled: Whether to enable (True) or disable (False) the rule
            
        Returns:
            True if rule was found and modified, False otherwise
        """
        with self.lock:
            for rule in self.rules:
                if rule.id == rule_id:
                    rule.enabled = enabled
                    return True
            return False
            
    def get_rules(self) -> List[DetectionRule]:
        """Return a copy of all rules."""
        with self.lock:
            return self.rules.copy()
            
    def start_detection(self):
        """Start the detection engine."""
        self.is_running = True
        
    def stop_detection(self):
        """Stop the detection engine."""
        self.is_running = False
        
    def process_packet(self, packet_data: Dict[str, Any]):
        """
        Process a network packet through all active rules.
        
        Args:
            packet_data: Dictionary containing packet information
        """
        if not self.is_running:
            return
            
        with self.lock:
            for rule in self.rules:
                if not rule.enabled:
                    continue
                    
                # Process based on rule type
                if rule.rule_type == RuleType.REGEX:
                    self._process_regex_rule(rule, packet_data)
                elif rule.rule_type == RuleType.PROTOCOL:
                    self._process_protocol_rule(rule, packet_data)
                elif rule.rule_type == RuleType.NETWORK:
                    self._process_network_rule(rule, packet_data)
                elif rule.rule_type == RuleType.CUSTOM:
                    self._process_custom_rule(rule, packet_data)
                    
    def _process_regex_rule(self, rule: DetectionRule, packet_data: Dict[str, Any]):
        """Process a regex-based rule."""
        try:
            payload = packet_data.get('payload', b'')
            if isinstance(payload, bytes):
                payload_str = payload.hex()
            else:
                payload_str = str(payload)
                
            if re.search(rule.pattern, payload_str, re.IGNORECASE):
                alert = DetectionAlert(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    severity=rule.severity,
                    timestamp=datetime.now(),
                    source=packet_data.get('src_ip', 'unknown'),
                    destination=packet_data.get('dst_ip', 'unknown'),
                    details={'matched_pattern': rule.pattern, 'payload_length': len(payload)},
                    matched_data=payload_str[:100]  # Limit matched data size
                )
                self.alerts.append(alert)
        except re.error:
            # Invalid regex pattern
            pass
            
    def _process_protocol_rule(self, rule: DetectionRule, packet_data: Dict[str, Any]):
        """Process a protocol-based rule."""
        protocol = packet_data.get('protocol', '').lower()
        
        if protocol == rule.pattern.lower():
            # Call registered callback if available
            if rule.callback:
                result = rule.callback(packet_data)
                if result:
                    alert = DetectionAlert(
                        rule_id=rule.id,
                        rule_name=rule.name,
                        severity=rule.severity,
                        timestamp=datetime.now(),
                        source=packet_data.get('src_ip', 'unknown'),
                        destination=packet_data.get('dst_ip', 'unknown'),
                        details=result,
                        matched_data=str(packet_data)
                    )
                    self.alerts.append(alert)
                    
    def _process_network_rule(self, rule: DetectionRule, packet_data: Dict[str, Any]):
        """Process a network-based rule."""
        # Check for IP addresses, ports, or other network patterns
        if rule.pattern.startswith('ip:'):
            ip_pattern = rule.pattern[3:]  # Remove 'ip:' prefix
            src_ip = packet_data.get('src_ip', '')
            dst_ip = packet_data.get('dst_ip', '')
            
            if ip_pattern in [src_ip, dst_ip]:
                alert = DetectionAlert(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    severity=rule.severity,
                    timestamp=datetime.now(),
                    source=src_ip,
                    destination=dst_ip,
                    details={'matched_ip': ip_pattern},
                    matched_data=str(packet_data)
                )
                self.alerts.append(alert)
                
        elif rule.pattern.startswith('port:'):
            port_pattern = rule.pattern[5:]  # Remove 'port:' prefix
            try:
                port_num = int(port_pattern)
                src_port = packet_data.get('src_port', 0)
                dst_port = packet_data.get('dst_port', 0)
                
                if port_num in [src_port, dst_port]:
                    alert = DetectionAlert(
                        rule_id=rule.id,
                        rule_name=rule.name,
                        severity=rule.severity,
                        timestamp=datetime.now(),
                        source=packet_data.get('src_ip', 'unknown'),
                        destination=packet_data.get('dst_ip', 'unknown'),
                        details={'matched_port': port_num},
                        matched_data=str(packet_data)
                    )
                    self.alerts.append(alert)
            except ValueError:
                # Invalid port number
                pass
                
    def _process_custom_rule(self, rule: DetectionRule, packet_data: Dict[str, Any]):
        """Process a custom rule with a callback function."""
        if rule.callback:
            try:
                result = rule.callback(packet_data)
                if result:
                    alert = DetectionAlert(
                        rule_id=rule.id,
                        rule_name=rule.name,
                        severity=rule.severity,
                        timestamp=datetime.now(),
                        source=packet_data.get('src_ip', 'unknown'),
                        destination=packet_data.get('dst_ip', 'unknown'),
                        details=result,
                        matched_data=str(packet_data)
                    )
                    self.alerts.append(alert)
            except Exception:
                # Callback raised an exception, ignore it
                pass
                
    def _check_iec104_suspicious_command(self, packet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check for suspicious IEC 104 commands."""
        if packet_data.get('protocol') != 'iec_104':
            return None
            
        payload = packet_data.get('payload', b'')
        if isinstance(payload, bytes) and len(payload) >= 6:
            # Check for Type IDs that indicate control commands
            type_id = payload[4] if len(payload) > 4 else 0
            if type_id in [0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37]:  # Control commands
                return {
                    'alert_type': 'IEC_104_Control_Command',
                    'description': f'Suspicious IEC 104 control command: Type ID {type_id}',
                    'iec_104_type_id': type_id
                }
        return None
        
    def _check_modbus_write_command(self, packet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check for Modbus write commands."""
        if packet_data.get('protocol') != 'modbus':
            return None
            
        payload = packet_data.get('payload', b'')
        if isinstance(payload, bytes) and len(payload) >= 7:
            # Extract function code (byte 7 in Modbus TCP)
            func_code = payload[7] if len(payload) > 7 else 0
            if func_code in [5, 6, 15, 16]:  # Write functions
                return {
                    'alert_type': 'Modbus_Write_Command',
                    'description': f'Modbus write command detected: Function {func_code}',
                    'modbus_function': func_code
                }
        return None
        
    def _check_dnp3_unauthorized_control(self, packet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check for DNP3 unauthorized control commands."""
        if packet_data.get('protocol') != 'dnp3':
            return None
            
        payload = packet_data.get('payload', b'')
        if isinstance(payload, bytes) and len(payload) >= 10:
            # DNP3 object header contains function codes
            function_code = payload[2] if len(payload) > 2 else 0
            if function_code in [3, 4, 5, 6, 7, 8]:  # Control function codes
                return {
                    'alert_type': 'DNP3_Control_Command',
                    'description': f'DNP3 control command detected: Function {function_code}',
                    'dnp3_function': function_code
                }
        return None
        
    def _check_s7comm_session_init(self, packet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check for S7COMM session initialization."""
        if packet_data.get('protocol') != 's7comm':
            return None
            
        payload = packet_data.get('payload', b'')
        if isinstance(payload, bytes) and len(payload) >= 4:
            # Check for S7COMM session init patterns
            if payload[0] == 0x03:  # Common S7COMM start byte
                return {
                    'alert_type': 'S7COMM_Session_Init',
                    'description': 'S7COMM session initialization detected',
                    's7comm_pattern': payload[:10].hex()
                }
        return None
        
    def _check_unusual_port_access(self, packet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check for access to unusual ports."""
        dst_port = packet_data.get('dst_port', 0)
        
        # Define suspicious ports for industrial protocols
        suspicious_ports = [2404, 502, 1502, 20000, 24000, 50400]  # IEC 104, Modbus, etc.
        
        if dst_port in suspicious_ports:
            return {
                'alert_type': 'Unusual_Port_Access',
                'description': f'Access to industrial protocol port: {dst_port}',
                'port': dst_port
            }
        return None
        
    def get_alerts(self, limit: int = 50) -> List[DetectionAlert]:
        """
        Get recent alerts.
        
        Args:
            limit: Maximum number of alerts to return
            
        Returns:
            List of recent alerts
        """
        with self.lock:
            # Return last 'limit' alerts
            return self.alerts[-limit:]
            
    def clear_alerts(self):
        """Clear all alerts."""
        with self.lock:
            self.alerts.clear()
            
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get detection engine statistics.
        
        Returns:
            Dictionary with statistics
        """
        with self.lock:
            active_rules = sum(1 for rule in self.rules if rule.enabled)
            total_alerts = len(self.alerts)
            
            # Count alerts by severity
            severity_counts = {}
            for alert in self.alerts:
                severity = alert.severity.value
                severity_counts[severity] = severity_counts.get(severity, 0) + 1
                
            return {
                'active_rules': active_rules,
                'total_rules': len(self.rules),
                'total_alerts': total_alerts,
                'alerts_by_severity': severity_counts,
                'engine_running': self.is_running
            }


class LiveDetectionManager:
    """
    Manages live detection of network traffic.
    """
    
    def __init__(self, detection_engine: DetectionEngine):
        self.engine = detection_engine
        self.monitoring_thread = None
        self.is_monitoring = False
        self.packet_callback = None
        
    def set_packet_callback(self, callback: Callable):
        """
        Set a callback function to receive packets for processing.
        
        Args:
            callback: Function that receives packets and returns them for processing
        """
        self.packet_callback = callback
        
    def start_monitoring(self):
        """Start live monitoring."""
        if self.is_monitoring:
            return
            
        self.is_monitoring = True
        self.engine.start_detection()
        self.monitoring_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitoring_thread.start()
        
    def stop_monitoring(self):
        """Stop live monitoring."""
        self.is_monitoring = False
        self.engine.stop_detection()
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=2.0)  # Wait up to 2 seconds for thread to finish
            
    def _monitor_loop(self):
        """Main monitoring loop."""
        while self.is_monitoring:
            if self.packet_callback:
                try:
                    # Get packets from callback (this would typically come from a live capture)
                    packets = self.packet_callback()
                    if packets:
                        for packet in packets:
                            self.engine.process_packet(packet)
                except Exception:
                    # Ignore exceptions in callback to keep monitoring running
                    pass
                    
            time.sleep(0.1)  # Small delay to prevent busy-waiting